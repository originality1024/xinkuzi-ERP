const view = document.getElementById('viewButton');
view.addEventListener('click', () => {
    window.location.href = 'view/view.html'; 
});