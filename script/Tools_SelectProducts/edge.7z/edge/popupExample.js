const example = document.getElementById('exampleButton');
example.addEventListener('click', () => {
    window.location.href = 'view/example.html';
})