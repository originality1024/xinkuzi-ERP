const Return = document.getElementById('returnButton')
Return.addEventListener('click', function() {
    window.location.href = '../popup.html';
})